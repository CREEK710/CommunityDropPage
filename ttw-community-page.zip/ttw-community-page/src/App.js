
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 to-indigo-800 text-white flex flex-col items-center justify-center p-8">
      <motion.h1 initial={{ opacity: 0, y: -50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="text-5xl font-bold mb-6 text-center">
        Tubular TimeWarp Community Hub 🔮
      </motion.h1>
      <Card className="max-w-2xl bg-purple-700 rounded-2xl shadow-2xl p-6">
        <CardContent>
          <p className="text-xl mb-4">
            Welcome to the official community space for the TTW Game — built by <span className="font-bold text-pink-400">Creek</span> for explorers of the TrOip Ecosystem.
          </p>
          <ul className="list-disc list-inside space-y-2 text-lg">
            <li>✨ Explore Galactic Souls, Astral Bodies & Origin Planets</li>
            <li>🕹 Get early access to game features and play-tests</li>
            <li>📢 Follow the creator on X: <a href="https://x.com/CREEKxTrOip" target="_blank" rel="noopener noreferrer" className="underline text-blue-300">CREEKxTrOip 🔮</a></li>
            <li>🌐 Upcoming Web3 tools, GameFi integrations & DeFi layers</li>
          </ul>
          <Button className="mt-6 w-full bg-pink-500 hover:bg-pink-600 text-xl">
            Join the TTW Journey
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
